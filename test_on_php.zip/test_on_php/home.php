<meta charset="utf-8">

 <body bgcolor="d5e9f7">
<center>
<br/><table border="10">
<tr><td><center><strong><h1><div align=left>Личный кабинет</strong></center></td></tr>
<tr><td><center><strong><tr><td><center><a href="test.php">начать тестирование<center></td></tr></strong></center></td></tr>
<tr><td><center><strong><tr><td><center><a href="pdf.php">вывод сертификата в pdf</center></td></tr></strong></center></td></tr>